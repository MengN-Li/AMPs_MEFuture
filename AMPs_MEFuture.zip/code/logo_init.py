
if __name__ == '__main__':
    main()
def main():
    f_positive = open('dev1.txt', 'r')
    f_negative = open('dev0.txt', 'r')
    f_total = open('PWAA_dev.csv', 'w')
    name_all_feature = []