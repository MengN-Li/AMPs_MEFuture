
import pickle
import csv
import pandas as pd
import pickle
import sys
import numpy as np

with open('Kspace_train.csv', 'r') as f:
    fl = open("Kspace_train.pkl", 'wb')
    reader = csv.reader(f)
    result = list(reader)
    result.remove(result[0])
    data_all = []
    for seq in result:
        data_each = []
        count = 0
        for j in seq:
            count += 1
            if count != 1:
                data_each.append(float(j))
        data_all.append(data_each)
    pickle.dump(data_all, fl)
    fl.close()

