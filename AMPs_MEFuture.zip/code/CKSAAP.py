class K_space:
    def __init__(self, k):
        self.k = k
        self.feature_name = []
        self.AA_list_sort = ['A', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'Y']
    def get_feature_name(self):
        for element in range(self.k + 1):
            element = str(element)
            prefix = 'Kspace_%s_space_' % element
            for i1 in self.AA_list_sort:
                for j1 in self.AA_list_sort:
                    self.feature_name.append(prefix + i1 + j1)
        return self.feature_name
    def main(self, sequence):
        two_mer_name = []
        for i2 in self.AA_list_sort:
            for j2 in self.AA_list_sort:
                combination = i2 + j2
                two_mer_name.append(combination)
        two_mer_dict = {}
        for item in two_mer_name:
            two_mer_dict[item] = 0
        for i, v in enumerate(sequence):
            if i + 2 + self.k > len(sequence):
                break
            else:
                now_k_mer = sequence[i:i + 2 + self.k:self.k + 1]
                if now_k_mer in two_mer_dict:
                    two_mer_dict[now_k_mer] += 1
        feature_vector = []
        for key, value in two_mer_dict.items():
            frequency = value / (len(sequence) - 1 - self.k)
            feature_vector.append(frequency)
        return feature_vector
def main():
    f_positive = open('train1.txt', 'r')
    f_negative = open('train0.txt', 'r')
    f_total = open('Kspace_train.csv', 'w')
    name_all_feature = []
    name_Kspace = K_space(5).get_feature_name()
    name_all_feature.extend(name_Kspace)
    f_total.write('class,')
    for ix, name in enumerate(name_all_feature):
        f_total.write(name)
        if ix != (len(name_all_feature) - 1):
            f_total.write(',')
        else:
            f_total.write('\n')
    for ele_pos in f_positive:
        if ele_pos[0] != '>':
            f_total.write('1')  # 标签！！！
            f_total.write(',')
            feature_total = []
            pos_sequence = ele_pos.strip()
            feature_0_space = K_space(0).main(pos_sequence)
            feature_1_space = K_space(1).main(pos_sequence)
            feature_2_space = K_space(2).main(pos_sequence)
            feature_3_space = K_space(3).main(pos_sequence)
            feature_4_space = K_space(4).main(pos_sequence)
            feature_5_space = K_space(5).main(pos_sequence)
            feature_total.extend(feature_0_space)
            feature_total.extend(feature_1_space)
            feature_total.extend(feature_2_space)
            feature_total.extend(feature_3_space)
            feature_total.extend(feature_4_space)
            feature_total.extend(feature_5_space)
            for ix1, pos_feature in enumerate(feature_total):
                f_total.write(str(pos_feature))
                if ix1 != (len(feature_total) - 1):
                    f_total.write(',')
                else:
                    f_total.write('\n')
    for ele_neg in f_negative:
        if ele_neg[0] != '>':
            f_total.write('0')
            f_total.write(',')
            feature_total = []
            neg_sequence = ele_neg.strip()
            feature_0_space = K_space(0).main(neg_sequence)
            feature_1_space = K_space(1).main(neg_sequence)
            feature_2_space = K_space(2).main(neg_sequence)
            feature_3_space = K_space(3).main(neg_sequence)
            feature_4_space = K_space(4).main(neg_sequence)
            feature_5_space = K_space(5).main(neg_sequence)
            feature_total.extend(feature_0_space)
            feature_total.extend(feature_1_space)
            feature_total.extend(feature_2_space)
            feature_total.extend(feature_3_space)
            feature_total.extend(feature_4_space)
            feature_total.extend(feature_5_space)
            for ix2, neg_feature in enumerate(feature_total):
                f_total.write(str(neg_feature))
                if ix2 != (len(feature_total) - 1):
                    f_total.write(',')
                else:
                    f_total.write('\n')
if __name__ == '__main__':
    main()