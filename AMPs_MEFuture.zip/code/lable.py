
import pickle

import sys
def lable_data(fasta_dir1,fasta_dir2):
    f1 = open(fasta_dir1)   
    f2 = open(fasta_dir2)  
    a=0
    b=0
    lable_list= []

    for line in f1:
        if line.startswith('>'): 
            lable_list.append(1) 
            a += 1
    for line in f2:
        if line.startswith('>'):   
            lable_list.append(0)  
            b += 1
    print(a)
    print(b)
    return lable_list
def main(seq_file1, seq_file2):
    print("标签，，")
    kk=lable_data(seq_file1,seq_file2)
    fl = open("lable_dev.pkl", 'wb')
    pickle.dump(kk, fl)
    fl.close()
if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])

