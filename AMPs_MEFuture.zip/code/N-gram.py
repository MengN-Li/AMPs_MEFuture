import pandas as pd
import numpy as np
import pickle
from keras.preprocessing.text import Tokenizer
import tensorflow as tf
import keras
import os
import Models.utils as utils
import sys

def tran_fasta_to_df(fasta_dir,type_name):
    f = open(fasta_dir)
    seq= []
    ids = []
    for line in f:
        if line.startswith('>'):
            name=line.replace('>','').split()
            ids.append(name[0])
        else:
            seq.append(line.replace('\n','').strip())
    print(len(ids))
    print(len(seq))
    assert(len(ids)==len(seq))
    f.close()
    df = pd.DataFrame(data={'id': ids ,type_name:seq})
    return df

def N_gram(seq,n):
    res = []
    for i in range(len(seq)-n+1):
        res.append(seq[i:i+n])
    return " ".join(res)

def gen_data(seq_file):
    test_seq = tran_fasta_to_df( seq_file,"seq")
    test_df = pd.concat([test_seq],axis=1)
    test_df["bigram"] = test_df['seq'].apply(N_gram,n=2)
    test_df["trigram"] = test_df['seq'].apply(N_gram,n=3)

    tok = pickle.load(open("./utils/tok.pkl", 'rb'))
    tok_bigram = pickle.load(open("./utils/tok_bigram.pkl", 'rb'))
    tok_trigram = pickle.load(open("./utils/tok_trigram.pkl", 'rb'))
if __name__ == "__main__":
    maxlen = 1200
    main(sys.argv[1], sys.argv[2])