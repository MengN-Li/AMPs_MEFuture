
class PWAA:
    def __init__(self):
        self.AA_list = ['A', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'Y']
    def get_feature_name(self):
        feature_name_list = []
        for element in self.AA_list:
            featureName = 'PWAA_feature_%s' % element
            feature_name_list.append(featureName)
        return feature_name_list
    def main(self, sequence):
        length_up_down = (len(sequence) - 1) / 2
        feature = []
        for aa_char in self.AA_list:
            sum_inter = 0
            if aa_char not in sequence:
                feature.append(0)
            else:
                for sequence_index, sequence_char in enumerate(sequence):
                    if sequence_char == aa_char:
                        j = sequence_index - length_up_down
                        sum_inter = sum_inter + (j + abs(j) / length_up_down)
                c = (1 / (length_up_down * (length_up_down + 1))) * sum_inter
                feature.append(c)
        return feature
def main():
    f_positive = open('dev1.txt', 'r')
    f_negative = open('dev0.txt', 'r')
    f_total = open('PWAA_dev.csv', 'w')
    name_all_feature = []
    name_PWAA = PWAA().get_feature_name()
    name_all_feature.extend(name_PWAA)
    f_total.write('class,')
    for ix, name in enumerate(name_all_feature):
        f_total.write(name)
        if ix != (len(name_all_feature) - 1):
            f_total.write(',')
        else:
            f_total.write('\n')
    for ele_pos in f_positive:
        if ele_pos[0] != '>':
            f_total.write('1')
            f_total.write(',')
            feature_total = []
            pos_sequence = ele_pos.strip()
            feature_PWAA = PWAA().main(pos_sequence)
            feature_total.extend(feature_PWAA)
            for ix1, pos_feature in enumerate(feature_total):
                f_total.write(str(pos_feature))
                if ix1 != (len(feature_total) - 1):
                    f_total.write(',')
                else:
                    f_total.write('\n')
    for ele_neg in f_negative:
        if ele_neg[0] != '>':
            f_total.write('0')  # 标签！！！
            f_total.write(',')
            feature_total = []
            neg_sequence = ele_neg.strip()
            feature_PWAA = PWAA().main(neg_sequence)
            feature_total.extend(feature_PWAA)
            for ix2, neg_feature in enumerate(feature_total):
                f_total.write(str(neg_feature))
                if ix2 != (len(feature_total) - 1):
                    f_total.write(',')
                else:
                    f_total.write('\n')
if __name__ == '__main__':
    main()
