from sklearn.metrics import *
import matplotlib.pyplot as plt
import numpy as np
from numpy import interp
from sklearn.preprocessing import label_binarize
import pandas as pd
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score, recall_score, f1_score

predict_loc = "./result/predict_file/cv_fold_80.9733139252789907_prediction.txt" #示例
predict_data = pd.read_csv(predict_loc,sep="\t")

true_label = [i for i in predict_data["label"]]
predict_label = [i for i in predict_data["Predicted_Class"]]

predict_data2 = pd.read_csv(predict_loc,sep="\t", names=['p0','p1'])
predict_score = predict_data2.to_numpy().max(axis=1)
print(classification_report(true_label,predict_label))
accuracy = accuracy_score(true_label, predict_label)
print("acc: ",accuracy)

recall = recall_score(true_label, predict_label, average='weighted')
print("召回率=敏感度sn: ",recall)

mcc=matthews_corrcoef(true_label, predict_label)
print("MCC: ", mcc)

f1 = f1_score(true_label, predict_label, average='weighted')
print("f1 Score: ", f1)

pr = precision_score(true_label,predict_label, average= 'micro')
print("pr: ", pr)
r= recall_score (true_label,predict_label, average= 'micro')
print("r: ", r)

label_names = ["classz", "classf"]
confusion = confusion_matrix(true_label, predict_label, labels=[i for i in range(len(label_names))])
plt.matshow(confusion, cmap=plt.cm.Oranges)
plt.colorbar()
for i in range(len(confusion)):
    for j in range(len(confusion)):
        plt.annotate(confusion[j,i], xy=(i, j), horizontalalignment='center', verticalalignment='center')
plt.ylabel('True label')
plt.xlabel('Predicted label')
plt.xticks(range(len(label_names)), label_names)
plt.yticks(range(len(label_names)), label_names)
plt.title("Confusion Matrix")
plt.show()

n_classes = len(label_names)
binarize_predict = label_binarize(true_label, classes=[i for i in range(n_classes)])
predict_score = predict_data.to_numpy()

fpr1, tpr1, _ = roc_curve(binarize_predict[:,0], [socre[0] for socre in predict_score])
roc_auc1 = auc(fpr1, tpr1)
fpr2, tpr2, _ = roc_curve(binarize_predict[:,0], [socre[1] for socre in predict_score])
roc_auc2 = auc(tpr2, fpr2)

print("roc_auc1 = ",roc_auc1)
print("roc_auc2 = ",roc_auc2)

lw = 2
plt.figure()
plt.plot(fpr1, tpr1, lw=lw, label='ROC curve of {0} (area = {1:0.4f})'.format(label_names[0], roc_auc1))
plt.plot(tpr2, fpr2, lw=lw, label='ROC curve of {0} (area = {1:0.4f})'.format(label_names[1], roc_auc2))
plt.plot([0.0, 1.0], [0.0, 1.0], 'k--', lw=lw)
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Multi-class receiver operating characteristic ')
plt.legend(loc="lower right")
plt.show()